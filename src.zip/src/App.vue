<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>

export default {
  name: 'App'
}
</script>

<style>
*{
  font-family: 'Avenir', Helvetica, Arial, sans-serif;  
  padding: 0px;
  margin: 0px;
  text-decoration: none;
  list-style:none;
}
</style>
