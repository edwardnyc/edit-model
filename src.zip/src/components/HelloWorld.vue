<template>
  <div>
    <div class= "main-content">
        <div class="opotions-box">
          <div class="ports">
            <div class= "btn-box">
              <button>组件</button>
              <button>页面</button>
            </div>
            <div class= "tags-content">
              <div v-for="(every,i) in all" :key="i"  class="tag-item">
                      <img v-if="every.img" :src='"../assets/images/" + every.img + ".png"'
                       @click="lipush(every)" draggable="true"
                         @dragstart="dragstarthandle(every,`origin${i}`,$event)">
                      <span v-if="every.text">{{every.text}}</span>
              </div>
            </div>
          </div>
       </div>
        <div  class= "drag-box" @drop.self="boxDropHandle($event)" @dragover.prevent="dragoverhandle()">
        <list-item v-for="(item,index) in draglist" :key ='index' :item='item' :alleclect="all" :index="index"
         @select="select"   :draglist.sync="draglist" :class ="[checknum==index ?  'active':'','drag-item']"></list-item>
       </div>
    </div>

     <div class="setting-box">
        <div class="setting-title" v-if="draglist.length!==0">
              <span>
                    组件设置
              </span>
              <span style = "font-size:10px;vertical-align:bottom;color:#c4c4c4;padding-left:20px">
                  {{draglist[checknum].text}}
              </span>
        </div>
     </div>
  </div>
</template>
<script>
import ListItem from './list-item';
import {mapGetters} from "vuex";
export default {
  name: 'HelloWorld',
  components:{ 
      ListItem
  },
  data () {
    return {
      draglist:[],//最终的组件列表
      all:[{img:1,text:'轮播广告',type:1},{img:2,text:'商品模块',type:2},{img:3,text:'店铺头部',type:3},{img:4,text:'物品栏',type:4},{img:5,text:'文字模块',type:5},{img:6,text:'优惠卷',type:6},{text:'更多组件'}],//能点击的type列表
      checknum:0
    }
  },
  created(){
  },
  methods:{
    lipush(item){
      console.log(item)
      // this.draglist.push({'type':item.type});
    },
     dragstarthandle(item,index,e){
          e.dataTransfer.setData('data', index);
      },
      select(i){
            this.checknum =i;
      },
      boxDropHandle(e){
            var getIndex = e.dataTransfer.getData('data');     
              const i =   getIndex.substring(6);
              this.draglist.push(this.all[i])
      },
       dragoverhandle(){},      
  },
  watch:{
    draglist(){
      this.$store.commit('updateData',this.draglist);
    }
  },
}
</script>
<style scoped lang="scss">
*{
  padding: 0px;
  margin: 0px;
  user-select: none;
}
.main-content{
  border: 1px solid rgba(#4c4c4c,0.1);
  box-sizing: border-box;
  float: left;
  overflow: hidden;
  margin-top: 20vh;
  margin-left: 18vw;
  height: 70vh;;
}
        .opotions-box{
          float: left;
          width: 400px;
          height: 100vh;
          margin-right: 100px;
          .ports{
            width: 100%;
              .btn-box{
                width: 100%;
                display: flex;
                  justify-content: space-around;                
                button{
                    width: 118px;
                    height: 46px;
                    border-radius: 30px;
                    border: 0;
                    background: #5CD6FF;
                    color: #ffffff;
                    cursor: pointer;
                    &:focus{
                      border: unset;
                      outline: none;
                    }
                }
              }
              .tags-content{
               .tag-item{
                 display: inline-block;
                  width: 30%;                 
                  height: 90px;
                  box-sizing: border-box;
                  border: 1px solid rgba(#4c4c4c,0.5);
                  border-radius: 5px;
                   margin: 10px 10%
                }
              }
          }
        }
        .drag-box{
          width: 375px;
          border: 1px solid #5CD6FF;
          // position: absolute;
          float: left;
          left: 50%;
          height: 100%;
          overflow-y: scroll;
          // transform: translateX(-50%);
          .drag-item{
            width: 100%;
          }
        }
        .setting-box{
          overflow: hidden;
            float: right;
            width: 360px;
            box-sizing: border-box;
            border-top:1px solid #4c4c4c;
            border-left:1px solid #4c4c4c;
            height: 100vh;
            .setting-title{
              width: 80%;
              margin: 20px 10% 0;
            }
        }
        .active{
          border: 1px dashed #5CD6FF;
          box-sizing: border-box;
        }
      
</style>
